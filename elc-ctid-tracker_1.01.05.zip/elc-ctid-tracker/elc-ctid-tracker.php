<?php
/**
 * Plugin Name: Certificate Tracker for LearnDash
 * Plugin URI: http://elearningcomplete.com
 * Description: Provides shortcode to render unique certificate ID on certificates and saves to Database.
 * Version: 1.01.05
 * Store ItemID: 12520
 * Author: Patrick F. Kellogg and Michael Dajewski
 * Author URI: http://www.elearningcomplete.com
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Updater block BEGIN */
if( ! class_exists( 'ELC_SL_Plugin_Updater' ) ) {
	require_once plugin_dir_path( __FILE__ ) . 'updater/ELC_SL_Plugin_Updater.php';
}

/**
 * Register action to initialise ELC Updater.
 */
add_action( 'admin_init', function () {
	$elc_updater = new ELC_SL_Plugin_Updater( __FILE__ );
} );

/**
 * Register plugin license page.
 * Do not add menu item to admin settings menu.
 */
add_action( 'admin_menu', function () {
	$page_callback = array( 'ELC_SL_Plugin_Updater', 'licenseFormHTML' );
	$menu_slug = basename( __FILE__, '.php' ) . '-license';
	$url = ELC_SL_Plugin_Updater::registerPluginLicensePage( $page_callback, $menu_slug );
} );

/**
 * Register action to process license activate/deactivate.
 */
add_action( 'admin_init', array( 'ELC_SL_Plugin_Updater', 'ELCLicenseActions' ) );

/**
 * Register action for admin notices.
 */
add_action( 'admin_notices', array( 'ELC_SL_Plugin_Updater', 'ELCLinenseAdminNotices' ) );
/** Updater block END */

/**
 * Add a new shortcode.
 */
add_shortcode( 'elc_certificate_id', 'elc_certificate_id' );

/**
 * Shortcode callback function.
 *
 * @param $atts
 * @return string|void
 */
function elc_certificate_id( $atts ) {

	if( 'sfwd-certificates' !== get_post_type() ) {
		// This shortcode works only for certificates.
		return;
	}

	// If we got here, we do assume it is a certificate for course or quiz.
	$user_id = get_current_user_id();

	if( $_id = $_REQUEST[ 'quiz' ] ) {
		// This is a quiz certificate.
		$st_sfwd_quizzes = get_user_meta( $user_id, '_sfwd-quizzes', true );
		if( $st_sfwd_quizzes ) {
			$quiz_time = $_REQUEST[ 'time' ];
			$pass_array = array_filter( $st_sfwd_quizzes, function ( $ar ) use ( $_id, $quiz_time ) {
				if( isset( $quiz_time ) ) {
					// User selected 'Certificate' link from 'profile' page.
					return ( $ar[ 'pass' ] == 1 && $ar[ 'quiz' ] == $_id && $ar[ 'time' ] == $quiz_time );
				} else {
					// User selected 'PRINT YOUR CERTIFICATE' button after passing the the quiz.
					return ( $ar[ 'pass' ] == 1 && $ar[ 'quiz' ] == $_id );
				}
			} );
		}
		foreach( $pass_array as $key => $val ) {
			$quiz_id_ar[] = array(
				'quiz' => $val[ 'quiz' ],
				'completed' => $val[ 'completed' ],
			);
		}
		// Get the last quiz from the array if there is no $_REQUEST[ 'time' ] set.
		// The same logic as in:
		// wp-content/plugins/sfwd-lms/includes/quiz/ld-quiz-info-shortcode.php:learndash_quizinfo()
		$_tstamp = end( $quiz_id_ar )[ 'completed' ];
	} elseif( $_id = $_REQUEST[ 'course_id' ] ) {
		// This is a course certificate.
		$_tstamp = get_user_meta( $user_id, 'course_completed_' . $_id, true );
	} else {
		return;
	}

	$certificate_meta_key = 'elc_certificate_ids';

	$saved_certificates = get_user_meta( $user_id, $certificate_meta_key, true );
	$saved_certificates = maybe_unserialize( $saved_certificates );

	if( ! is_array( $saved_certificates ) ) {
		$saved_certificates = array();
	}

	$prefix = $atts[ 'prefix' ];

	$pattern = '/[^A-Za-z0-9 ]/';
	// Alphanumeric, no special characters, upto 8 characters long.
	if( ! empty( $prefix ) ) $prefix = substr( preg_replace( $pattern, '', $prefix ), 0, 8 ) . '-';

	$certificate_full_id = $prefix . $_tstamp . '-' . $_id . '-' . $user_id;

	// Search in $saved_certificates for $certificate_full_id
	$found = array_filter( $saved_certificates, function ( $ar ) use ( $_id, $certificate_full_id, $saved_certificates ) {
		if( $ar[ 'cid' ] === $certificate_full_id ) {
			return $ar;
		}
	} );

	if( empty( $found ) ) {
		// Create new certificate item.
		$certificate_meta_value_array = array(
			'cid' => $prefix . $_tstamp . '-' . $_id . '-' . $user_id,
		);
		// Add it into $saved_certificates array.
		$saved_certificates[] = $certificate_meta_value_array;
		// Update user meta.
		update_user_meta( $user_id, $certificate_meta_key, $saved_certificates );
	}

	return $certificate_full_id;
}

/**
 * Helper function to get from post content the shortcode by it's tag name
 * and return the array of shortcode arguments.
 *
 * @param  string $content
 * @param  array|string $tagname
 * @return array|void
 */
function elc_certificate_id_get_shortcode_args( $content, $tagname ) {
	$pattern = is_array( $tagname ) ? get_shortcode_regex( $tagname ) : get_shortcode_regex( array( $tagname ) );
	if( preg_match_all( '/' . $pattern . '/s', $content, $matches ) ) {
		$keys = array();
		$shortcode_args = array();
		$i = 0;
		$output = array();
		foreach( $matches[ 0 ] as $key => $value ) {
			// $matches[3] return the shortcode attribute(s) as string.
			// Replace space with '&' for parse_str() function.
			$get = str_replace( ' ', '&', str_replace( '"', '', $matches[ 3 ][ $key ] ) );
			parse_str( $get, $output );

			// Get all shortcode attribute keys.
			$keys = array_unique( array_merge( $keys, array_keys( $output ) ) );
			$shortcode_args[ $i ] = $output;
			$i++;
		}
		return $shortcode_args;
	} else {
		return;
	}
}

/**
 * Add full certificate ID to QRcode data and link.
 * This way we can pass the certificate ID as query parameter to certificate-verification page.
 *
 * @param $out
 * @param $pairs
 * @param $atts
 * @return mixed
 */
function elc_certificate_id_query_param( $out ) {
	// Get 'Certificate ID' prefix from certificate post content.
	$post_id = get_the_ID();
	$content_raw = get_post_field( 'post_content', $post_id, 'raw' );
	$shortcode_args = elc_certificate_id_get_shortcode_args( $content_raw, array( 'elc_certificate_id' ) );
	$cert_id_prefix = $shortcode_args[ 0 ][ 'prefix' ] ? $shortcode_args[ 0 ][ 'prefix' ] : '';

	$certificate_full_id = elc_certificate_id( array( 'prefix' => $cert_id_prefix ) );
	$out[ 'data' ] .= '?certificate_id=' . $certificate_full_id;
	$out[ 'link' ] .= '?certificate_id=' . $certificate_full_id;
	return $out;
}

/**
 * Filter a shortcode’s default attributes.
 * The 'su_qrcode' id is actually 'qrcode'.
 */
add_filter( 'shortcode_atts_qrcode', 'elc_certificate_id_query_param' );
